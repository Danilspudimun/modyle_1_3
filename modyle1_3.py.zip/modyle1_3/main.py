name = 'John'
print(name)
age = 25
print(age)
age = (age + 1)
print(age)
is_student = True
print(is_student)